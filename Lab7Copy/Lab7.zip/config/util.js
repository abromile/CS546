const path = require('path');
let ASHLEY_SETTINGS = {
    debug: false,
    sep: path.sep
};

module.exports = ASHLEY_SETTINGS;