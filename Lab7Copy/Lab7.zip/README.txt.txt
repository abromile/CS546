I put my style.css file in the same place you had yours too because it couldn't
find it in the assets folder even after changing the path in the main html for
some reason.

I would also like to add that I don't think I much of a choice but to add things
for the sake of styling since this assignment just consisted of printing a list
of attributes and a title. There wasn't really much to style here in the first
place so I hope what I did was acceptable.

Another thing, you said we could not update the data modules but I and several
other people in my group found a few typos in your code and fixed them. The functions
themselves, however, were not changed.(You were comparing string id with int id)