module.exports = {
    events: require("./events"),
    people: require("./people"),
    locations: require("./locations")
};